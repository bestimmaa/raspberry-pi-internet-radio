from distutils.core import setup

setup(name='slideshow',
      version='1.0',
      py_modules=['slideshow'],
      )